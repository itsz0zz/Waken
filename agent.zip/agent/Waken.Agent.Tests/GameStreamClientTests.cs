using Microsoft.Extensions.Logging.Abstractions;

namespace Waken.Agent.Tests;

public sealed class GameStreamClientTests : IDisposable
{
    private static readonly TimeSpan TestTimeout = TimeSpan.FromSeconds(15);
    private readonly string _dataDir = Directory.CreateTempSubdirectory("waken-agent-tests-").FullName;
    private readonly CancellationTokenSource _timeout = new(TestTimeout);

    private GameStreamClient Client(FakeSunshine sunshine, string password = FakeSunshine.Password) => new(
        new AgentOptions
        {
            SunshineHost = "127.0.0.1",
            SunshinePort = sunshine.Port,
            SunshineUser = FakeSunshine.User,
            SunshinePassword = password,
            DataDir = _dataDir,
        },
        NullLogger<GameStreamClient>.Instance);

    [Theory]
    [InlineData(nameof(SunshineApi.PairingId))]
    [InlineData(nameof(SunshineApi.Legacy))]
    public async Task Pairs_then_lists_the_apps(string api)
    {
        await using var sunshine = await FakeSunshine.StartAsync(Enum.Parse<SunshineApi>(api));

        var apps = await Client(sunshine).AppsAsync(_timeout.Token);

        Assert.Equal(["Desktop", "Steam Big Picture"], apps.Select(app => app.Title));
    }

    [Fact]
    public async Task Never_approves_the_pairing_request_of_another_device()
    {
        await using var sunshine = await FakeSunshine.StartAsync(SunshineApi.PairingId);
        var foreignId = sunshine.AddForeignPairingRequest("waken");

        await Client(sunshine).AppsAsync(_timeout.Token);

        Assert.DoesNotContain(foreignId, sunshine.ApprovedIds);
    }

    [Fact]
    public async Task Pairs_only_once()
    {
        await using var sunshine = await FakeSunshine.StartAsync(SunshineApi.PairingId);

        await Client(sunshine).AppsAsync(_timeout.Token);
        await Client(sunshine).AppsAsync(_timeout.Token);

        Assert.Equal(1, sunshine.PairingsStarted);
    }

    [Fact]
    public async Task A_wrong_admin_password_fails_quickly_and_says_so()
    {
        await using var sunshine = await FakeSunshine.StartAsync(SunshineApi.PairingId);

        var error = await Assert.ThrowsAsync<InvalidOperationException>(() => Client(sunshine, "wrong").AppsAsync(_timeout.Token));

        Assert.Contains("SunshinePassword", error.Message);
    }

    [Fact]
    public async Task Launches_then_resumes_the_same_app_without_closing_it()
    {
        await using var sunshine = await FakeSunshine.StartAsync(SunshineApi.PairingId);
        var client = Client(sunshine);

        var launched = await client.LaunchAsync("Steam Big Picture", 1920, 1080, 60, _timeout.Token);
        await client.LaunchAsync("Steam Big Picture", 1920, 1080, 60, _timeout.Token);

        Assert.Equal("rtsp://127.0.0.1:48010", launched.RtspSessionUrl);
        Assert.Equal(257, launched.ServerCodecModeSupport);
        Assert.Equal(["launch", "resume"], sunshine.Verbs);
    }

    [Fact]
    public async Task An_unknown_app_does_not_close_the_running_game()
    {
        await using var sunshine = await FakeSunshine.StartAsync(SunshineApi.PairingId);
        var client = Client(sunshine);
        await client.LaunchAsync("Steam Big Picture", 1920, 1080, 60, _timeout.Token);

        await Assert.ThrowsAsync<InvalidOperationException>(() => client.LaunchAsync("Not configured", 1920, 1080, 60, _timeout.Token));

        Assert.Equal(["launch"], sunshine.Verbs);
    }

    public void Dispose()
    {
        _timeout.Dispose();
        Directory.Delete(_dataDir, recursive: true);
    }
}
