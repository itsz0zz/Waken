using System.Formats.Asn1;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Xml.Linq;

namespace Waken.Agent;

/// <summary>
/// Talks to Sunshine through the GameStream protocol (HTTP 47989 / HTTPS 47984) as a paired client.
/// Because the agent runs on the PC itself, it can also type the pairing PIN into Sunshine through
/// Sunshine's admin API (47990), which makes pairing fully automatic.
/// </summary>
public sealed class GameStreamClient
{
    private readonly AgentOptions _o;
    private readonly ILogger<GameStreamClient> _log;
    private readonly string _uniqueId;
    private X509Certificate2 _clientCert;
    private X509Certificate2? _serverCert;
    private readonly SemaphoreSlim _pairLock = new(1, 1);

    public GameStreamClient(AgentOptions o, ILogger<GameStreamClient> log)
    {
        _o = o;
        _log = log;
        Directory.CreateDirectory(o.DataDir);
        _uniqueId = LoadOrCreate(Path.Combine(o.DataDir, "uniqueid.txt"), () => Convert.ToHexString(RandomNumberGenerator.GetBytes(8)));
        _clientCert = LoadOrCreateClientCert();
        var serverPem = Path.Combine(o.DataDir, "server.pem");
        if (File.Exists(serverPem)) _serverCert = X509Certificate2.CreateFromPem(File.ReadAllText(serverPem));
    }

    private const int HttpsPortOffset = -5;
    private const int AdminPortOffset = 1;
    private static readonly TimeSpan PairingTimeout = TimeSpan.FromSeconds(30);
    private static readonly TimeSpan LegacyPinDelay = TimeSpan.FromMilliseconds(1500);

    private string HttpBase => $"http://{_o.SunshineHost}:{_o.SunshinePort}";
    private string HttpsBase => $"https://{_o.SunshineHost}:{_o.SunshinePort + HttpsPortOffset}";
    private string AdminBase => $"https://{_o.SunshineHost}:{_o.SunshinePort + AdminPortOffset}";
    private string Common => $"uniqueid={_uniqueId}&uuid={Guid.NewGuid():N}";

    // ---------- Identity ----------

    private static string LoadOrCreate(string path, Func<string> create)
    {
        if (File.Exists(path)) return File.ReadAllText(path).Trim();
        var v = create();
        File.WriteAllText(path, v);
        return v;
    }

    private X509Certificate2 LoadOrCreateClientCert()
    {
        var pfx = Path.Combine(_o.DataDir, "client.pfx");
        if (!File.Exists(pfx))
        {
            using var rsa = RSA.Create(2048);
            var req = new CertificateRequest("CN=NVIDIA GameStream Client", rsa, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            using var cert = req.CreateSelfSigned(DateTimeOffset.UtcNow.AddDays(-1), DateTimeOffset.UtcNow.AddYears(20));
            File.WriteAllBytes(pfx, cert.Export(X509ContentType.Pfx));
        }
        // Windows SChannel needs a persisted private key for client authentication.
        var flags = OperatingSystem.IsWindows() ? X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet : X509KeyStorageFlags.Exportable;
        return X509CertificateLoader.LoadPkcs12FromFile(pfx, null, flags);
    }

    /// The raw signature bytes of a certificate (the BIT STRING after tbsCertificate and the algorithm).
    private static byte[] Signature(X509Certificate2 cert)
    {
        var reader = new AsnReader(cert.RawData, AsnEncodingRules.DER).ReadSequence();
        reader.ReadEncodedValue(); // tbsCertificate
        reader.ReadEncodedValue(); // signatureAlgorithm
        return reader.ReadBitString(out _);
    }

    // ---------- HTTP ----------

    private HttpClient PlainClient() => new() { Timeout = TimeSpan.FromMinutes(2) };

    private HttpClient TlsClient()
    {
        var handler = new HttpClientHandler
        {
            ClientCertificateOptions = ClientCertificateOption.Manual,
            // Sunshine uses a self-signed cert: pin the one received during pairing.
            ServerCertificateCustomValidationCallback = (_, cert, _, _) => _serverCert is null || cert?.RawData.AsSpan().SequenceEqual(_serverCert.RawData) == true,
        };
        handler.ClientCertificates.Add(_clientCert);
        return new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(30) };
    }

    private static async Task<XElement> GetXml(HttpClient http, string url, CancellationToken ct)
    {
        var xml = XElement.Parse(await http.GetStringAsync(url, ct));
        var status = (int?)xml.Attribute("status_code") ?? 200;
        if (status != 200) throw new InvalidOperationException($"Sunshine: {status} {(string?)xml.Attribute("status_message")}");
        return xml;
    }

    // ---------- Pairing ----------

    public async Task<bool> IsPairedAsync(CancellationToken ct)
    {
        if (_serverCert is null) return false;
        try
        {
            using var http = TlsClient();
            var info = await GetXml(http, $"{HttpsBase}/serverinfo?{Common}", ct);
            return (string?)info.Element("PairStatus") == "1";
        }
        catch (Exception e)
        {
            _log.LogWarning("serverinfo over TLS failed: {Message}", e.Message);
            return false;
        }
    }

    public async Task EnsurePairedAsync(CancellationToken ct)
    {
        await _pairLock.WaitAsync(ct);
        try
        {
            if (await IsPairedAsync(ct)) return;
            await PairAsync(ct);
        }
        finally { _pairLock.Release(); }
    }

    private async Task PairAsync(CancellationToken ct)
    {
        using var attempt = CancellationTokenSource.CreateLinkedTokenSource(ct);
        attempt.CancelAfter(PairingTimeout);
        try
        {
            await RunPairingAsync(attempt.Token);
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested)
        {
            throw new InvalidOperationException($"Appairage avec Sunshine sans réponse après {PairingTimeout.TotalSeconds:0} s.");
        }
        finally
        {
            // Releases whichever request is still waiting on Sunshine when a phase failed.
            await attempt.CancelAsync();
        }
    }

    private async Task RunPairingAsync(CancellationToken ct)
    {
        using var admin = new SunshineAdminClient(new Uri(AdminBase), _o.SunshineUser, _o.SunshinePassword);
        var usesPairingIds = await admin.UsesPairingIdsAsync(ct);

        var pin = RandomNumberGenerator.GetInt32(0, 10000).ToString("D4");
        var salt = RandomNumberGenerator.GetBytes(16);
        var aesKey = SHA256.HashData([.. salt, .. Encoding.UTF8.GetBytes(pin)])[..16];
        using var aes = Aes.Create();
        aes.Key = aesKey;
        var clientPem = Encoding.UTF8.GetBytes(_clientCert.ExportCertificatePem());
        using var http = PlainClient();

        // Recent Sunshine answers 409 while an earlier attempt with the same uniqueid is pending, so each attempt gets its own.
        // Older versions give the PIN to the first pending session, where a stable id is what replaces a stale one.
        var pairingClientId = usesPairingIds ? Convert.ToHexString(RandomNumberGenerator.GetBytes(8)) : _uniqueId;
        var deviceName = $"waken-{Convert.ToHexStringLower(RandomNumberGenerator.GetBytes(8))}";
        var pairUrl = $"{HttpBase}/pair?uniqueid={pairingClientId}&uuid={Guid.NewGuid():N}&devicename={deviceName}&updateState=1";

        // 1. getservercert: blocks until the PIN is entered in Sunshine. We enter it ourselves.
        var getCert = GetXml(http, $"{pairUrl}&phrase=getservercert&salt={Convert.ToHexString(salt)}&clientcert={Convert.ToHexString(clientPem)}", ct);
        string? pairingId = null;
        if (usesPairingIds) pairingId = await admin.WaitForPairingIdAsync(deviceName, getCert, ct);
        else await Task.Delay(LegacyPinDelay, ct);

        // Not awaited yet: recent Sunshine only answers it after phase 4.
        var pinAccepted = admin.SubmitPinAsync(pin, pairingId, ct);
        if (await Task.WhenAny(getCert, pinAccepted) == pinAccepted) await pinAccepted;
        var certXml = await getCert;
        if ((string?)certXml.Element("paired") != "1") throw new InvalidOperationException("Sunshine a refusé l'appairage (getservercert).");
        var serverCert = X509Certificate2.CreateFromPem(Encoding.UTF8.GetString(Convert.FromHexString((string)certXml.Element("plaincert")!)));

        // 2. client challenge
        var clientChallenge = RandomNumberGenerator.GetBytes(16);
        var chXml = await GetXml(http, $"{pairUrl}&clientchallenge={Convert.ToHexString(aes.EncryptEcb(clientChallenge, PaddingMode.None))}", ct);
        var resp = aes.DecryptEcb(Convert.FromHexString((string)chXml.Element("challengeresponse")!), PaddingMode.None);
        var serverResponseHash = resp[..32];
        var serverChallenge = resp[32..48];

        // 3. answer the server challenge
        var clientSecret = RandomNumberGenerator.GetBytes(16);
        var answer = SHA256.HashData([.. serverChallenge, .. Signature(_clientCert), .. clientSecret]);
        var secXml = await GetXml(http, $"{pairUrl}&serverchallengeresp={Convert.ToHexString(aes.EncryptEcb(answer, PaddingMode.None))}", ct);
        var pairingSecret = Convert.FromHexString((string)secXml.Element("pairingsecret")!);
        var serverSecret = pairingSecret[..16];
        var serverSig = pairingSecret[16..];

        // Verify the server really knows the PIN and owns its certificate.
        var expected = SHA256.HashData([.. clientChallenge, .. Signature(serverCert), .. serverSecret]);
        using var serverKey = serverCert.GetRSAPublicKey()!;
        if (!expected.AsSpan().SequenceEqual(serverResponseHash) || !serverKey.VerifyData(serverSecret, serverSig, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1))
        {
            await http.GetAsync($"{HttpBase}/unpair?uniqueid={pairingClientId}", ct);
            throw new CryptographicException("Vérification du serveur échouée (PIN incorrect ou attaque MITM).");
        }

        // 4. our pairing secret, signed with our key
        using var clientKey = _clientCert.GetRSAPrivateKey()!;
        var clientSig = clientKey.SignData(clientSecret, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        var doneXml = await GetXml(http, $"{pairUrl}&clientpairingsecret={Convert.ToHexString([.. clientSecret, .. clientSig])}", ct);
        if ((string?)doneXml.Element("paired") != "1") throw new InvalidOperationException("Appairage refusé (clientpairingsecret).");
        await pinAccepted;

        // 5. confirm over TLS with our client certificate
        _serverCert = serverCert;
        File.WriteAllText(Path.Combine(_o.DataDir, "server.pem"), serverCert.ExportCertificatePem());
        using var tls = TlsClient();
        var final = await GetXml(tls, $"{HttpsBase}/pair?{Common}&devicename=waken&updateState=1&phrase=pairchallenge", ct);
        if ((string?)final.Element("paired") != "1") throw new InvalidOperationException("Appairage TLS final refusé.");
        _log.LogInformation("Paired with Sunshine");
    }

    // ---------- Apps & launch ----------

    public async Task<List<(int Id, string Title)>> AppsAsync(CancellationToken ct)
    {
        await EnsurePairedAsync(ct);
        using var http = TlsClient();
        var xml = await GetXml(http, $"{HttpsBase}/applist?{Common}", ct);
        return xml.Elements("App").Select(a => ((int)a.Element("ID")!, (string)a.Element("AppTitle")!)).ToList();
    }

    public sealed record LaunchResult(string AppVersion, string? GfeVersion, string RtspSessionUrl, int ServerCodecModeSupport, string RiKey, int RiKeyId);

    public async Task<LaunchResult> LaunchAsync(string appTitle, int width, int height, int fps, CancellationToken ct)
    {
        await EnsurePairedAsync(ct);
        using var http = TlsClient();
        var info = await GetXml(http, $"{HttpsBase}/serverinfo?{Common}", ct);
        var apps = await AppsAsync(ct);
        var app = apps.FirstOrDefault(a => string.Equals(a.Title, appTitle, StringComparison.OrdinalIgnoreCase));
        // No fallback to Desktop: launching another app would close the game that is running.
        if (app == default) throw new InvalidOperationException($"Application « {appTitle} » introuvable dans Sunshine. Disponibles : {string.Join(", ", apps.Select(a => a.Title))}.");

        var riKey = RandomNumberGenerator.GetBytes(16);
        var riKeyId = RandomNumberGenerator.GetInt32(int.MaxValue);
        var running = (int?)info.Element("currentgame") ?? 0;
        var verb = running == app.Id ? "resume" : "launch";
        if (running != 0 && running != app.Id) await GetXml(http, $"{HttpsBase}/cancel?{Common}", ct);

        var xml = await GetXml(http,
            $"{HttpsBase}/{verb}?{Common}&appid={app.Id}&mode={width}x{height}x{fps}&additionalStates=1&sops=0" +
            $"&rikey={Convert.ToHexString(riKey)}&rikeyid={riKeyId}&localAudioPlayMode=0&surroundAudioInfo=196610&remoteControllersBitmap=0&gcmap=0", ct);

        return new LaunchResult(
            AppVersion: (string?)info.Element("appversion") ?? "7.1.431.-1",
            GfeVersion: (string?)info.Element("GfeVersion"),
            RtspSessionUrl: (string?)xml.Element("sessionUrl0") ?? "",
            ServerCodecModeSupport: (int?)info.Element("ServerCodecModeSupport") ?? 0,
            RiKey: Convert.ToHexString(riKey),
            RiKeyId: riKeyId);
    }

    public async Task QuitAsync(CancellationToken ct)
    {
        using var http = TlsClient();
        await GetXml(http, $"{HttpsBase}/cancel?{Common}", ct);
    }
}
