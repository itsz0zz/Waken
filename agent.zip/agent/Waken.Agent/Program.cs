using System.Diagnostics;
using System.Text.Json;
using Waken.Agent;

var builder = WebApplication.CreateBuilder(args);
// Written by install-agent.ps1, readable by SYSTEM and administrators only. Environment variables would be readable by every user.
if (OperatingSystem.IsWindows())
{
    var configFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Waken", "agent.json");
    builder.Configuration.AddJsonFile(configFile, optional: true);
}
var options = builder.Configuration.GetSection("Agent").Get<AgentOptions>() ?? new AgentOptions();
var bearerToken = new BearerToken(options.Token);
builder.Services.AddSingleton(options);
builder.Services.AddSingleton<GameStreamClient>();
builder.Services.ConfigureHttpJsonOptions(o => o.SerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase);

var app = builder.Build();

app.Use(async (ctx, next) =>
{
    if (ctx.Request.Path.StartsWithSegments("/health")) { await next(); return; }
    if (!bearerToken.Matches(ctx.Request.Headers.Authorization.ToString()))
    {
        ctx.Response.StatusCode = StatusCodes.Status401Unauthorized;
        return;
    }
    await next();
});

// Answers as soon as Windows has booted, before Sunshine: the app uses it for the "Le PC répond" step.
app.MapGet("/health", () => Results.Ok(new { ok = true, machine = Environment.MachineName, uptimeSeconds = Environment.TickCount64 / 1000 }));

app.MapGet("/apps", (GameStreamClient gs, CancellationToken ct) =>
    CallSunshine(async () => Results.Ok((await gs.AppsAsync(ct)).Select(a => new { id = a.Id, title = a.Title }))));

app.MapPost("/launch", (LaunchRequest req, GameStreamClient gs, CancellationToken ct) =>
    CallSunshine(async () => Results.Ok(await gs.LaunchAsync(req.App, req.Width, req.Height, req.Fps, ct))));

app.MapPost("/quit", (GameStreamClient gs, CancellationToken ct) =>
    CallSunshine(async () =>
    {
        await gs.QuitAsync(ct);
        return Results.NoContent();
    }));

app.MapPost("/shutdown", () => Run("shutdown", "/s /t 5 /c \"Waken\""));
app.MapPost("/sleep", () => Run("rundll32.exe", "powrprof.dll,SetSuspendState 0,1,0"));

app.Run();

// The app shows this detail: "Application introuvable" is more useful than a bare 500.
async Task<IResult> CallSunshine(Func<Task<IResult>> call)
{
    try
    {
        return await call();
    }
    catch (Exception e)
    {
        app.Logger.LogError(e, "Sunshine call failed");
        return Results.Problem(e.Message, statusCode: StatusCodes.Status502BadGateway);
    }
}

static IResult Run(string file, string args)
{
    if (!OperatingSystem.IsWindows()) return Results.Problem("Windows uniquement", statusCode: 501);
    Process.Start(new ProcessStartInfo(file, args) { CreateNoWindow = true, UseShellExecute = false });
    return Results.Accepted();
}

namespace Waken.Agent
{
    public sealed class AgentOptions
    {
        public string Token { get; set; } = "";
        public string SunshineHost { get; set; } = "localhost";
        /// <summary>Sunshine's base port. HTTPS is base - 5, the admin API base + 1.</summary>
        public int SunshinePort { get; set; } = 47989;
        public string SunshineUser { get; set; } = "admin";
        public string SunshinePassword { get; set; } = "";
        public string DataDir { get; set; } = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Waken");
    }

    public sealed record LaunchRequest(string App, int Width, int Height, int Fps, bool Hevc);
}
